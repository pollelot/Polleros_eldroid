package com.polleros.activity5
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var alertDialogButton: Button
    private lateinit var datePickerButton: Button
    private lateinit var timePickerButton: Button
    private lateinit var selectedDateTimeTextView: TextView

    private val dateFormatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private val timeFormatter = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        alertDialogButton = findViewById(R.id.alertDialogButton)
        datePickerButton = findViewById(R.id.datePickerButton)
        timePickerButton = findViewById(R.id.timePickerButton)
        selectedDateTimeTextView = findViewById(R.id.selectedDateTimeTextView)

        alertDialogButton.setOnClickListener {
            showAlertDialog()
        }

        datePickerButton.setOnClickListener {
            showDatePicker()
        }

        timePickerButton.setOnClickListener {
            showTimePicker()
        }
    }

    private fun showAlertDialog() {
        val alertDialog = AlertDialog.Builder(this)
            .setTitle("Alert Dialog")
            .setMessage("This is an example of an AlertDialog.")
            .setPositiveButton("OK") { _, _ ->
                showToast("OK clicked")
            }
            .setNegativeButton("Cancel") { _, _ ->
                showToast("Cancel clicked")
            }
            .create()

        alertDialog.show()
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, selectedYear, selectedMonth, selectedDay ->
            val selectedDate = Calendar.getInstance()
            selectedDate.set(selectedYear, selectedMonth, selectedDay)
            val formattedDate = dateFormatter.format(selectedDate.time)
            selectedDateTimeTextView.text = "Selected date: $formattedDate"
        }, year, month, day)

        datePickerDialog.show()
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(this, TimePickerDialog.OnTimeSetListener { _: TimePicker, selectedHour: Int, selectedMinute: Int ->
            val selectedTime = Calendar.getInstance()
            selectedTime.set(Calendar.HOUR_OF_DAY, selectedHour)
            selectedTime.set(Calendar.MINUTE, selectedMinute)
            val formattedTime = timeFormatter.format(selectedTime.time)
            selectedDateTimeTextView.text = "Selected time: $formattedTime"
        }, hour, minute, false)

        timePickerDialog.show()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}